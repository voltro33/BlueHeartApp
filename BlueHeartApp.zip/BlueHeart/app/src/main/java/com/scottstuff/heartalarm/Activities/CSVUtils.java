package com.scottstuff.heartalarm.Activities;

import java.io.IOException;
import java.io.Writer;
import java.util.List;

public class CSVUtils {
    private static final char DEFAULT_SEPARATOR = ',';

    public static void writeLine(Writer w, List<String> values) throws IOException {
        writeLine(w, values, DEFAULT_SEPARATOR, ' ');
    }

    public static void writeLine(Writer w, List<String> values, char separators) throws IOException {
        writeLine(w, values, separators, ' ');
    }

    public static void writeLine(Writer w, List<String> values, char separators, char customQuote) throws IOException {
        boolean first = true;

        // If a custom quote character is defined, use it for field values that need escaping
        if (customQuote == ' ') {
            customQuote = DEFAULT_SEPARATOR;
        }

        StringBuilder sb = new StringBuilder();
        for (String value : values) {
            if (!first) {
                sb.append(separators);
            }
            if (customQuote == ' ' || value.indexOf(separators) > -1 || value.indexOf('\n') > -1 || value.indexOf('\r') > -1) {
                sb.append(customQuote).append(value.replace(String.valueOf(customQuote), String.valueOf(customQuote) + String.valueOf(customQuote))).append(customQuote);
            } else {
                sb.append(value);
            }
            first = false;
        }
        sb.append("\n");
        w.append(sb.toString());
    }
}
